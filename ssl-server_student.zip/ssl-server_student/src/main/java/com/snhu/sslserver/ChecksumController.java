package com.snhu.sslserver;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

/**
 * Name: Alexander Pessinis
 * File: ChecksumController.java
 * Purpose: Maintain code scaling and readability by moving cryptographic
 *          functions to a dedicated controller class.
 *
 * Description: Computes and returns a SHA-256 checksum for given input data.
 */
@RestController
public class ChecksumController {

    @GetMapping("/checksum")
    public ResponseEntity<Map<String, String>> getChecksum() {
        String data = "Hello World Check Sum!";
        Map<String, String> body = new HashMap<>();

        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(data.getBytes(StandardCharsets.UTF_8));

            StringBuilder hexString = new StringBuilder();
            for (byte b : hashBytes) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }

            
            body.put("checksum", hexString.toString());
            body.put("algorithm", "SHA-256");
            return ResponseEntity.ok(body);

        } catch (NoSuchAlgorithmException e) {
        	//preventing stack trace exposure
            body.put("error", "Checksum algorithm not available");
            body.put("details", "SHA-256 provider not found in this runtime");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(body);
        } catch (RuntimeException e) {
            // Catch-all for any other errors
            body.put("error", "Unexpected error computing checksum");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(body);
        }
    }
}