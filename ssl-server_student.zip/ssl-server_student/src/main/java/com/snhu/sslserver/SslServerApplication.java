package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Name: Alexander Pessinis
 * File: SslServerApplication.java
 * Purpose: Entry point to run the SSL-enabled server.
 * 
 * NOTICE: The checksum and cryptography logic has been moved to
 *          ChecksumController.java to maintain file readability
 *          and separation.
 */

@SpringBootApplication
public class SslServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SslServerApplication.class, args);
    }

}